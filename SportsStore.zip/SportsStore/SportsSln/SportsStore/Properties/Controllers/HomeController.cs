﻿using Microsoft.AspNetCore.Mvc;

namespace SportsStore.Properties.Controllers
{
	public class HomeController : Controller
	{
		public IActionResult Index() => View();	 
	}
}
